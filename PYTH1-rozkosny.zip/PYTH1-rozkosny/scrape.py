import requests
import re
from bs4 import BeautifulSoup

stranky =["https://www.skoleni-ict.cz/kurz/Uvod-do-umele-inteligence-a-strojoveho-uceni--AI1.aspx",
    "https://www.skoleni-ict.cz/blog/multitasking-fungsuje/",
    "https://www.skoleni-ict.cz/kurz/Jazyk-SQL-zaklady-dotazovani-a-manipulace-s-daty-v-SQL-Serveru-SQL1.aspx"
       ]

nefunkci_stranky = []

def zkontroluj_stranku(stranka):
    try:
        r = requests.get(stranka)
        if r.status_code != 200:
            print(f'stranka {stranka} nefunguje')
            nefunkci_stranky.append(stranka)
        else:
            print(f'stranka {stranka} funguje')
            if '/kurz/' in stranka:
                text = BeautifulSoup(r.content,"html.parser")
                cena = re.findall(r'lblCena">(.*)Kč',str(text))[0]
                print(cena)
                

    except ConnectionError:
        print(f'ke strance {stranka} se nebylo mozne pripojit')

for i in stranky:
    zkontroluj_stranku(i)

