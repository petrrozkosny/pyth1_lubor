class Okres:
    # Promenna tridy
    zeme = 'Cesko'
    
    # Promenne instanci, pocet_obyvatel je nepovinny argument
    def __init__(self,kraj,pocet_obyvatel = None,):
        self.kraj = kraj
        self.obyvatele = pocet_obyvatel
        

    def __str__(self):
        return f'kraj:{self.kraj},pocet obyvatel: {self.obyvatele}'

    def pozdrav(self):
        print('Ahoj okrese')
        
#kolin = Okres('Stredocesky',100000)
kolin.pozdrav()