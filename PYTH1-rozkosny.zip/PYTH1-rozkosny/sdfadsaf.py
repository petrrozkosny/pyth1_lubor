import requests


class Firma:

    def __init__(self,web,sidlo=None):
        self.web = web
        self.sidlo = sidlo

    def get(self):
        r = requests
        print(r.encoding)

ict_pro = Firma('https://www.ictpro.cz')
ict_pro.sidlo = 'Sochorova'
print(ict_pro.sidlo)